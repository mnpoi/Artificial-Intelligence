from kaggle_environments import make

def run_multiple_times(agent1, agent2, num_runs=10):
    env = make("mab", debug=True)
    total_wins_submission = 0
    total_wins_submission4 = 0

    for run in range(1, num_runs + 1):
        env.reset()
        env.run([agent1, agent2])

        # Get the final rewards for each agent
        reward1 = env.state[0]["reward"]
        reward4 = env.state[1]["reward"]

        # Determine the winner based on the final rewards
        if reward1 > reward4:
            total_wins_submission += 1
        elif reward1 < reward4:
            total_wins_submission4 += 1

        # Calculate win probabilities
        prob_win_random = total_wins_submission / run
        prob_win_submission = total_wins_submission4 / run

        # Print results for each run
        print(f"Run {run} - Win probability for submission.py: {prob_win_random:.2%}")
        print(f"Run {run} - Win probability for submission4.py: {prob_win_submission:.2%}")
        print("-" * 40)

    print(f"Final win probability for submission.py: {prob_win_random:.2%}")
    print(f"Final win probability for submission4.py: {prob_win_submission:.2%}")

# Run the environment multiple times and compare win probabilities
run_multiple_times("random", "submission.py", num_runs=100)
