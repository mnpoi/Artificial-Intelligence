import torch
import torch.nn as nn
import torch
from typing import Tuple
import torch.nn.functional as F
from torch.distributions import Categorical


class ActorCritic(nn.Module):
    def __init__(
        self,
        state_dim: int,
        num_action: int,
        num_hidden_units: int,
    ):
        super().__init__()
        self.common = nn.Linear(state_dim, num_hidden_units)
        self.actor = nn.Linear(num_hidden_units, num_action)
        self.critic = nn.Linear(num_hidden_units, 1)

    def forward(self, x: torch.Tensor):
        x = F.relu(self.common(x))
        prob = F.softmax(self.actor(x), dim=-1)
        value = self.critic(x)
        dist = Categorical(prob)
        return dist, value
