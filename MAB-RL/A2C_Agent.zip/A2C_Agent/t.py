from kaggle_environments import make, evaluate

env_test = make("mab", debug=True)

steps = env_test.run(["submission.py", "agent_random.py"])
with open("save_result.txt", 'w') as f:
    for step in steps:
        f.write(str(step) + '\n')
print(steps[-1])
