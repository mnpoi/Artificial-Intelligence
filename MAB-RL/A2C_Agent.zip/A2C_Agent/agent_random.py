import random

def agent_random_(obs, config):
    #print(obs)
    #print(config)
    valid_moves = [bnd for bnd in range(config['banditCount'])]
    return random.choice(valid_moves)
