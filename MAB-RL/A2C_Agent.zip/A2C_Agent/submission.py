import random
import numpy as np
from a2cagent import ActorCritic
from MABenv import MABanditGym
import torch
from kaggle_environments import make, evaluate


# returns a compiled model
# identical to the previous one
envs = MABanditGym()
num_inputs = envs.observation_space.shape[0] * 2
num_outputs = envs.action_space.n
hidden_size = 256
use_cuda = torch.cuda.is_available()
device = torch.device("cuda" if use_cuda else "cpu")
model_bandit = ActorCritic(num_inputs, num_outputs, hidden_size).to(device)
state_dict = torch.load('a2cnet.pth')
model_bandit.load_state_dict(state_dict['model'])

class MABanditPlayer:
    global model_bandit

    def __init__(self, observation, configuration):

        self.nrounds = configuration['episodeSteps']
        self.banditCount = configuration['banditCount']
        self.prev_reward = 0
        self.grid = -np.ones((self.nrounds, 2))
        self.obs = np.array(self.grid).reshape(self.nrounds * 2)
        self.prev_reward = 0
        # StableBaselines throws error if these are not defined

    def reset(self):
        # print(env.obs)
        self.env.reset()
        self.grid = -np.ones((self.nrounds, 2))
        self.obs = np.array(self.grid).reshape(self.nrounds * 2)
        self.prev_reward = 0
        return self.obs

    def play(self, observation, configuration):
        bandit = 0
        if observation['step'] > 0:

            for pos in range(0, 2):
                # print(current_obs)
                self.grid[observation['step'] - 1][pos] = observation['lastActions'][pos]
            new_reward = observation['reward']
            reward = new_reward - self.prev_reward
            self.prev_reward = new_reward
            self.obs = np.array(self.grid).reshape(self.nrounds * 2)

            # Convert state into a batched tensor (batch size = 1)
            state = torch.from_numpy(np.expand_dims(self.obs, axis=0).astype(np.float32)).to(device)
            # Run the model and to get action probabilities and critic value
            dist, value = model_bandit(state)
            # Sample next action from the action probability distribution
            action = dist.sample().cpu()
            # bandit = model_bandit.predict_classes(state) #state = tf.expand_dims(state, 0)
            bandit = action.numpy()

        else:
            valid_moves = [bnd for bnd in range(configuration['banditCount'])]
            bandit = np.dtype('int32').type(random.choice(valid_moves))

        return (bandit)




# Create the environment


# Set seed for experiment reproducibility
seed = 2023
random.seed(seed)
np.random.seed(seed)

observation0 = [{'remainingOverageTime': 60,
                 'step': 0,
                 'agentIndex': 0,
                 'reward': 0,
                 'lastActions': []}]
configuration0 = {'episodeSteps': 2000, 'actTimeout': 0.25, 'runTimeout': 1200, 'banditCount': 100, 'decayRate': 0.97,
                  'sampleResolution': 100}

mab_player = MABanditPlayer(observation0, configuration0)


def torch_agent(observation, configuration):
    # print(observation)
    # print(configuration)

    global mab_player
    bandit = 0
    bandit = (mab_player.play(observation, configuration)).item()
    return int(bandit)
