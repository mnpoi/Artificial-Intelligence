import numpy as np
import gym
import tensorflow as tf


from kaggle_environments import make, evaluate
from gym import spaces
import random

class MABanditGym:

    def __init__(self, agent2="random"):
        ks_env = make("mab", debug=True)
        self.env = ks_env.train([None, agent2])
        self.nrounds = 2000
        self.banditCount = ks_env.configuration.banditCount
        self.prev_reward = 0

        # Learn about spaces here: http://gym.openai.com/docs/#spaces
        self.action_space = spaces.Discrete(self.banditCount)
        low = -np.ones((self.nrounds,), dtype=np.float32)
        high = -low * (self.banditCount - 1)
        self.observation_space = spaces.Box(low, high, dtype=np.float32)
        # Tuple corresponding to the min and max possible rewards
        self.reward_range = (-10, 1)
        self.grid = -np.ones((self.nrounds, 2))
        self.obs = np.array(self.grid).reshape(self.nrounds * 2)
        # StableBaselines throws error if these are not defined
        self.spec = None
        self.metadata = None

    def reset(self):
        # print(env.obs)
        self.env.reset()
        self.grid = -np.ones((self.nrounds, 2))
        self.obs = np.array(self.grid).reshape(self.nrounds * 2)
        self.prev_reward = 0
        return self.obs

    def change_reward(self, old_reward, done):
        if old_reward == 1000:  # The agent won the game
            return 0
        elif done:  # The opponent won the game
            return -10
        else:  # Reward 1/2000
            return old_reward

    def step(self, action):
        _ = {}
        # Check if agent's move is valid
        is_valid = (int(action) in range(0, self.banditCount))
        # valid_moves = [bnd for bnd in range(config.banditCount)]

        if is_valid:  # Play the "move"
            current_obs = self.env.step(int(action))

            for pos in range(0, 2):
                # print(current_obs)
                self.grid[current_obs[0]['step'] - 1][pos] = current_obs[0]['lastActions'][pos]
            self.obs = np.array(self.grid).reshape(self.nrounds * 2)
            old_reward = current_obs[0]['reward']
            done = (current_obs[0]['step'] == self.nrounds - 1 and current_obs[0][
                'reward'] < 600)  # current_obs[1]['observation']['reward']
            reward = old_reward - self.prev_reward  # self.change_reward(old_reward, done)
            self.prev_reward = old_reward
        else:  # End the game and penalize agent
            reward, done, _ = -10, True, {}
        # print(self.obs, reward, done, _  )
        return self.obs, reward, done, _

    def seed(self, seed=None):
        self.np_random, seed = gym.utils.seeding.np_random(seed)
        return [seed]


if __name__ == '__main__':
    # Create the environment for training tasks
    env = MABanditGym(agent2="random")
    # Set seed for experiment reproducibility
    seed = 42
    env.seed(seed)
    random.seed(seed)
    tf.random.set_seed(seed)
    np.random.seed(seed)

    # Small epsilon value for stabilizing division operations
    eps = np.finfo(np.float32).eps.item()

    s = env.reset()
    n_s, r, d, _ = env.step(0)
    print('test env')
